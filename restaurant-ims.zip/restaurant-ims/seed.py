"""
Loads sample data so the API can be explored immediately after setup.
Run with: python seed.py
"""

from app.database import SessionLocal, Base, engine
from app import models

Base.metadata.create_all(bind=engine)
db = SessionLocal()

try:
    # Skip if already seeded
    if db.query(models.Ingredient).first():
        print("Database already has data. Skipping seed.")
    else:
        chicken = models.Ingredient(
            name="Chicken", unit="g", quantity_on_hand=5000, unit_cost=0.35, reorder_threshold=1000
        )
        rice = models.Ingredient(
            name="Rice", unit="g", quantity_on_hand=10000, unit_cost=0.08, reorder_threshold=2000
        )
        spices = models.Ingredient(
            name="Spice Mix", unit="g", quantity_on_hand=2000, unit_cost=0.5, reorder_threshold=300
        )
        db.add_all([chicken, rice, spices])
        db.flush()

        biryani = models.Recipe(name="Chicken Biryani", selling_price=250)
        db.add(biryani)
        db.flush()

        db.add_all(
            [
                models.RecipeIngredient(
                    recipe_id=biryani.id, ingredient_id=chicken.id, quantity_required=250
                ),
                models.RecipeIngredient(
                    recipe_id=biryani.id, ingredient_id=rice.id, quantity_required=200
                ),
                models.RecipeIngredient(
                    recipe_id=biryani.id, ingredient_id=spices.id, quantity_required=20
                ),
            ]
        )

        staff = models.Staff(name="Ramesh Kumar", role="Head Chef", monthly_salary=25000)
        db.add(staff)

        db.commit()
        print("Seed data loaded: 3 ingredients, 1 recipe (Chicken Biryani), 1 staff member.")
        print("Try: POST /sales/  with {\"recipe_id\": 1, \"quantity\": 2}")

finally:
    db.close()
