# Restaurant IMS — Inventory Management System

A backend system for restaurants and cloud kitchens to track raw-material inventory,
link menu items to recipes (BOM), automatically deduct stock on every sale, and
monitor profit margins in real time.

Built with **FastAPI**, **PostgreSQL**, and **SQLAlchemy**.

---

## Why this exists

Restaurants typically track inventory on paper or spreadsheets, which makes it
hard to know:
- How much raw stock is actually left
- What a dish really costs to make
- Which items are close to running out
- How much margin each sale generates

This system solves that by linking every **ingredient** to every **recipe** through
a Bill of Materials (BOM). When a sale is recorded, stock is deducted automatically
based on the recipe, and the margin is calculated from ingredient cost vs. selling price.

---

## Features

- **Ingredient inventory** — track quantity on hand, unit cost, and reorder threshold
- **Recipes / BOM** — define how many units of each ingredient a menu item needs
- **Sales recording** — one call deducts stock across all ingredients in a recipe
- **Low-stock alerts** — flag ingredients below their reorder threshold
- **Margin dashboard** — cost, revenue, and profit per recipe and overall
- **Staff records** — basic staff + salary tracking
- **Auto-generated API docs** via FastAPI's Swagger UI

---

## Tech Stack

| Layer | Tech |
|---|---|
| API framework | FastAPI |
| Database | PostgreSQL |
| ORM | SQLAlchemy 2.0 |
| Validation | Pydantic v2 |
| Migrations | Alembic (optional, see below) |
| Containerization | Docker + docker-compose |

---

## Project Structure

```
restaurant-ims/
├── app/
│   ├── main.py            # FastAPI app entrypoint
│   ├── database.py         # DB engine & session
│   ├── models.py           # SQLAlchemy ORM models
│   ├── schemas.py          # Pydantic request/response models
│   ├── crud.py             # DB operations
│   └── routers/
│       ├── ingredients.py  # Inventory endpoints
│       ├── recipes.py      # Recipe / BOM endpoints
│       ├── sales.py        # Sale recording + auto stock deduction
│       ├── staff.py        # Staff CRUD
│       └── dashboard.py    # Margin & low-stock reports
├── seed.py                 # Sample data loader
├── requirements.txt
├── docker-compose.yml
├── .env.example
└── README.md
```

---

## Getting Started

### Option A — Docker (recommended)

```bash
git clone https://github.com/<your-username>/restaurant-ims.git
cd restaurant-ims
cp .env.example .env
docker-compose up --build
```

API will be live at `http://localhost:8000`
Interactive docs at `http://localhost:8000/docs`

### Option B — Local Python

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Set up PostgreSQL and update .env with your connection string
cp .env.example .env

# Run the app
uvicorn app.main:app --reload
```

### Load sample data (optional)

```bash
python seed.py
```
This creates a few ingredients, one recipe, and records a sample sale so
you can explore the API immediately.

---

## Example Workflow

1. **Add ingredients** — `POST /ingredients/` (e.g. "Chicken", "Rice", "Spices")
2. **Create a recipe** — `POST /recipes/` (e.g. "Chicken Biryani") and attach a BOM:
   how many grams of chicken, rice, spices it needs
3. **Record a sale** — `POST /sales/` with `recipe_id` and `quantity`
   → stock for each linked ingredient is deducted automatically
4. **Check the dashboard** — `GET /dashboard/margins` to see cost vs. revenue
   per recipe, and `GET /dashboard/low-stock` for reorder alerts

---

## API Overview

| Method | Endpoint | Description |
|---|---|---|
| POST | `/ingredients/` | Add new ingredient |
| GET | `/ingredients/` | List all ingredients |
| PATCH | `/ingredients/{id}` | Update stock / cost |
| POST | `/recipes/` | Create recipe with BOM |
| GET | `/recipes/{id}` | Get recipe with ingredient breakdown & cost |
| POST | `/sales/` | Record a sale (auto-deducts stock) |
| GET | `/dashboard/margins` | Profit margin report |
| GET | `/dashboard/low-stock` | Ingredients below reorder threshold |
| POST | `/staff/` | Add staff member |
| GET | `/staff/` | List staff with salaries |

Full interactive documentation is auto-generated at `/docs` once the server is running.

---

## Roadmap

- [ ] JWT-based authentication for multi-restaurant support
- [ ] Supplier & purchase-order tracking
- [ ] React/Streamlit frontend dashboard
- [ ] Export reports to CSV/PDF

---

## License

MIT — free to use and modify.
