from datetime import datetime
from pydantic import BaseModel, ConfigDict


# ---------- Ingredient ----------

class IngredientBase(BaseModel):
    name: str
    unit: str
    quantity_on_hand: float = 0
    unit_cost: float = 0
    reorder_threshold: float = 0


class IngredientCreate(IngredientBase):
    pass


class IngredientUpdate(BaseModel):
    quantity_on_hand: float | None = None
    unit_cost: float | None = None
    reorder_threshold: float | None = None


class IngredientOut(IngredientBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


# ---------- Recipe / BOM ----------

class RecipeIngredientIn(BaseModel):
    ingredient_id: int
    quantity_required: float


class RecipeIngredientOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    ingredient_id: int
    ingredient_name: str
    quantity_required: float
    unit: str


class RecipeCreate(BaseModel):
    name: str
    selling_price: float
    ingredients: list[RecipeIngredientIn]


class RecipeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    selling_price: float
    ingredient_cost: float  # computed: sum of (unit_cost * quantity_required)
    margin: float  # computed: selling_price - ingredient_cost
    ingredients: list[RecipeIngredientOut]


# ---------- Sale ----------

class SaleCreate(BaseModel):
    recipe_id: int
    quantity: int = 1


class SaleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    recipe_id: int
    quantity: int
    total_revenue: float
    total_cost: float
    profit: float
    sold_at: datetime


# ---------- Staff ----------

class StaffCreate(BaseModel):
    name: str
    role: str
    monthly_salary: float


class StaffOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    role: str
    monthly_salary: float
    joined_at: datetime


# ---------- Dashboard ----------

class MarginReportItem(BaseModel):
    recipe_id: int
    recipe_name: str
    units_sold: int
    total_revenue: float
    total_cost: float
    total_profit: float


class LowStockItem(BaseModel):
    ingredient_id: int
    name: str
    quantity_on_hand: float
    reorder_threshold: float
    unit: str
