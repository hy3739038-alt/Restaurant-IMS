from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import crud, schemas
from app.database import get_db

router = APIRouter(prefix="/recipes", tags=["Recipes"])


@router.post("/", response_model=schemas.RecipeOut, status_code=201)
def add_recipe(data: schemas.RecipeCreate, db: Session = Depends(get_db)):
    recipe = crud.create_recipe(db, data)
    return crud.serialize_recipe(recipe)


@router.get("/", response_model=list[schemas.RecipeOut])
def list_recipes(db: Session = Depends(get_db)):
    return [crud.serialize_recipe(r) for r in crud.get_recipes(db)]


@router.get("/{recipe_id}", response_model=schemas.RecipeOut)
def get_recipe(recipe_id: int, db: Session = Depends(get_db)):
    recipe = crud.get_recipe(db, recipe_id)
    return crud.serialize_recipe(recipe)
