from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import crud, schemas
from app.database import get_db

router = APIRouter(prefix="/sales", tags=["Sales"])


@router.post("/", response_model=schemas.SaleOut, status_code=201)
def create_sale(data: schemas.SaleCreate, db: Session = Depends(get_db)):
    """Records a sale and automatically deducts stock based on the recipe's BOM."""
    sale = crud.record_sale(db, data)
    return crud.serialize_sale(sale)


@router.get("/", response_model=list[schemas.SaleOut])
def list_sales(db: Session = Depends(get_db)):
    return [crud.serialize_sale(s) for s in crud.get_sales(db)]
