from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import crud, schemas
from app.database import get_db

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/margins", response_model=list[schemas.MarginReportItem])
def margin_report(db: Session = Depends(get_db)):
    """Revenue, cost, and profit per recipe, based on recorded sales."""
    return crud.get_margin_report(db)


@router.get("/low-stock", response_model=list[schemas.LowStockItem])
def low_stock_alerts(db: Session = Depends(get_db)):
    """Ingredients at or below their reorder threshold."""
    return crud.get_low_stock(db)
