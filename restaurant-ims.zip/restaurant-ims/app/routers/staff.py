from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import crud, schemas
from app.database import get_db

router = APIRouter(prefix="/staff", tags=["Staff"])


@router.post("/", response_model=schemas.StaffOut, status_code=201)
def add_staff(data: schemas.StaffCreate, db: Session = Depends(get_db)):
    return crud.create_staff(db, data)


@router.get("/", response_model=list[schemas.StaffOut])
def list_staff(db: Session = Depends(get_db)):
    return crud.get_staff_list(db)
