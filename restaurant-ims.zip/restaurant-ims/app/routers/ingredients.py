from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import crud, schemas
from app.database import get_db

router = APIRouter(prefix="/ingredients", tags=["Ingredients"])


@router.post("/", response_model=schemas.IngredientOut, status_code=201)
def add_ingredient(data: schemas.IngredientCreate, db: Session = Depends(get_db)):
    return crud.create_ingredient(db, data)


@router.get("/", response_model=list[schemas.IngredientOut])
def list_ingredients(db: Session = Depends(get_db)):
    return crud.get_ingredients(db)


@router.get("/{ingredient_id}", response_model=schemas.IngredientOut)
def get_ingredient(ingredient_id: int, db: Session = Depends(get_db)):
    return crud.get_ingredient(db, ingredient_id)


@router.patch("/{ingredient_id}", response_model=schemas.IngredientOut)
def update_ingredient(
    ingredient_id: int, data: schemas.IngredientUpdate, db: Session = Depends(get_db)
):
    return crud.update_ingredient(db, ingredient_id, data)
