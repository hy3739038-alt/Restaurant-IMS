from fastapi import FastAPI

from app.database import Base, engine
from app.routers import ingredients, recipes, sales, staff, dashboard

# Creates tables on startup if they don't exist yet.
# For production, prefer Alembic migrations over this.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Restaurant IMS",
    description=(
        "An inventory management system for restaurants and cloud kitchens. "
        "Tracks ingredients, links menu items to recipes (BOM), auto-deducts "
        "stock on every sale, and reports profit margins."
    ),
    version="1.0.0",
)

app.include_router(ingredients.router)
app.include_router(recipes.router)
app.include_router(sales.router)
app.include_router(staff.router)
app.include_router(dashboard.router)


@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "message": "Restaurant IMS API is running. Visit /docs for API docs."}
