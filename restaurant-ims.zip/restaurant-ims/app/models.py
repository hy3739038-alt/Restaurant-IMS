from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    DateTime,
    ForeignKey,
)
from sqlalchemy.orm import relationship

from app.database import Base


class Ingredient(Base):
    """A raw inventory item, e.g. Chicken, Rice, Cooking Oil."""

    __tablename__ = "ingredients"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False, index=True)
    unit = Column(String, nullable=False)  # e.g. "g", "ml", "pcs"
    quantity_on_hand = Column(Float, nullable=False, default=0)
    unit_cost = Column(Float, nullable=False, default=0)  # cost per unit
    reorder_threshold = Column(Float, nullable=False, default=0)

    recipe_links = relationship("RecipeIngredient", back_populates="ingredient")


class Recipe(Base):
    """A sellable menu item, e.g. Chicken Biryani."""

    __tablename__ = "recipes"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False, index=True)
    selling_price = Column(Float, nullable=False)

    ingredients = relationship(
        "RecipeIngredient", back_populates="recipe", cascade="all, delete-orphan"
    )
    sales = relationship("Sale", back_populates="recipe")


class RecipeIngredient(Base):
    """The Bill of Materials (BOM) — links a recipe to the ingredients it needs."""

    __tablename__ = "recipe_ingredients"

    id = Column(Integer, primary_key=True, index=True)
    recipe_id = Column(Integer, ForeignKey("recipes.id"), nullable=False)
    ingredient_id = Column(Integer, ForeignKey("ingredients.id"), nullable=False)
    quantity_required = Column(Float, nullable=False)  # per single unit of the recipe

    recipe = relationship("Recipe", back_populates="ingredients")
    ingredient = relationship("Ingredient", back_populates="recipe_links")


class Sale(Base):
    """A record of a recipe being sold. Triggers automatic stock deduction."""

    __tablename__ = "sales"

    id = Column(Integer, primary_key=True, index=True)
    recipe_id = Column(Integer, ForeignKey("recipes.id"), nullable=False)
    quantity = Column(Integer, nullable=False)
    total_revenue = Column(Float, nullable=False)
    total_cost = Column(Float, nullable=False)  # ingredient cost at time of sale
    sold_at = Column(DateTime, default=datetime.utcnow)

    recipe = relationship("Recipe", back_populates="sales")


class Staff(Base):
    """Basic staff record with salary tracking."""

    __tablename__ = "staff"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    role = Column(String, nullable=False)
    monthly_salary = Column(Float, nullable=False)
    joined_at = Column(DateTime, default=datetime.utcnow)
