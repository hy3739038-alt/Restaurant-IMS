from fastapi import HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app import models, schemas


# ---------- Ingredients ----------

def create_ingredient(db: Session, data: schemas.IngredientCreate) -> models.Ingredient:
    existing = db.query(models.Ingredient).filter(models.Ingredient.name == data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Ingredient already exists")
    ingredient = models.Ingredient(**data.model_dump())
    db.add(ingredient)
    db.commit()
    db.refresh(ingredient)
    return ingredient


def get_ingredients(db: Session) -> list[models.Ingredient]:
    return db.query(models.Ingredient).order_by(models.Ingredient.name).all()


def get_ingredient(db: Session, ingredient_id: int) -> models.Ingredient:
    ingredient = db.query(models.Ingredient).filter(models.Ingredient.id == ingredient_id).first()
    if not ingredient:
        raise HTTPException(status_code=404, detail="Ingredient not found")
    return ingredient


def update_ingredient(
    db: Session, ingredient_id: int, data: schemas.IngredientUpdate
) -> models.Ingredient:
    ingredient = get_ingredient(db, ingredient_id)
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(ingredient, field, value)
    db.commit()
    db.refresh(ingredient)
    return ingredient


# ---------- Recipes ----------

def create_recipe(db: Session, data: schemas.RecipeCreate) -> models.Recipe:
    existing = db.query(models.Recipe).filter(models.Recipe.name == data.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Recipe already exists")

    recipe = models.Recipe(name=data.name, selling_price=data.selling_price)
    db.add(recipe)
    db.flush()  # get recipe.id before commit

    for item in data.ingredients:
        ingredient = get_ingredient(db, item.ingredient_id)
        link = models.RecipeIngredient(
            recipe_id=recipe.id,
            ingredient_id=ingredient.id,
            quantity_required=item.quantity_required,
        )
        db.add(link)

    db.commit()
    db.refresh(recipe)
    return recipe


def _recipe_cost(recipe: models.Recipe) -> float:
    return sum(link.quantity_required * link.ingredient.unit_cost for link in recipe.ingredients)


def serialize_recipe(recipe: models.Recipe) -> schemas.RecipeOut:
    cost = _recipe_cost(recipe)
    return schemas.RecipeOut(
        id=recipe.id,
        name=recipe.name,
        selling_price=recipe.selling_price,
        ingredient_cost=round(cost, 2),
        margin=round(recipe.selling_price - cost, 2),
        ingredients=[
            schemas.RecipeIngredientOut(
                ingredient_id=link.ingredient_id,
                ingredient_name=link.ingredient.name,
                quantity_required=link.quantity_required,
                unit=link.ingredient.unit,
            )
            for link in recipe.ingredients
        ],
    )


def get_recipe(db: Session, recipe_id: int) -> models.Recipe:
    recipe = db.query(models.Recipe).filter(models.Recipe.id == recipe_id).first()
    if not recipe:
        raise HTTPException(status_code=404, detail="Recipe not found")
    return recipe


def get_recipes(db: Session) -> list[models.Recipe]:
    return db.query(models.Recipe).order_by(models.Recipe.name).all()


# ---------- Sales (core business logic: deduct stock on sale) ----------

def record_sale(db: Session, data: schemas.SaleCreate) -> models.Sale:
    recipe = get_recipe(db, data.recipe_id)

    # 1. Check enough stock is available for every ingredient in the BOM
    shortages = []
    for link in recipe.ingredients:
        needed = link.quantity_required * data.quantity
        if link.ingredient.quantity_on_hand < needed:
            shortages.append(
                f"{link.ingredient.name}: need {needed}{link.ingredient.unit}, "
                f"have {link.ingredient.quantity_on_hand}{link.ingredient.unit}"
            )
    if shortages:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient stock for this sale: {'; '.join(shortages)}",
        )

    # 2. Deduct stock for every ingredient in the recipe's BOM
    for link in recipe.ingredients:
        link.ingredient.quantity_on_hand -= link.quantity_required * data.quantity

    # 3. Record the sale with cost/revenue snapshot at time of sale
    unit_cost = _recipe_cost(recipe)
    sale = models.Sale(
        recipe_id=recipe.id,
        quantity=data.quantity,
        total_revenue=recipe.selling_price * data.quantity,
        total_cost=unit_cost * data.quantity,
    )
    db.add(sale)
    db.commit()
    db.refresh(sale)
    return sale


def serialize_sale(sale: models.Sale) -> schemas.SaleOut:
    return schemas.SaleOut(
        id=sale.id,
        recipe_id=sale.recipe_id,
        quantity=sale.quantity,
        total_revenue=sale.total_revenue,
        total_cost=sale.total_cost,
        profit=round(sale.total_revenue - sale.total_cost, 2),
        sold_at=sale.sold_at,
    )


def get_sales(db: Session) -> list[models.Sale]:
    return db.query(models.Sale).order_by(models.Sale.sold_at.desc()).all()


# ---------- Staff ----------

def create_staff(db: Session, data: schemas.StaffCreate) -> models.Staff:
    staff = models.Staff(**data.model_dump())
    db.add(staff)
    db.commit()
    db.refresh(staff)
    return staff


def get_staff_list(db: Session) -> list[models.Staff]:
    return db.query(models.Staff).order_by(models.Staff.name).all()


# ---------- Dashboard ----------

def get_margin_report(db: Session) -> list[schemas.MarginReportItem]:
    rows = (
        db.query(
            models.Sale.recipe_id,
            models.Recipe.name,
            func.sum(models.Sale.quantity).label("units_sold"),
            func.sum(models.Sale.total_revenue).label("total_revenue"),
            func.sum(models.Sale.total_cost).label("total_cost"),
        )
        .join(models.Recipe, models.Recipe.id == models.Sale.recipe_id)
        .group_by(models.Sale.recipe_id, models.Recipe.name)
        .all()
    )
    return [
        schemas.MarginReportItem(
            recipe_id=r.recipe_id,
            recipe_name=r.name,
            units_sold=r.units_sold,
            total_revenue=round(r.total_revenue, 2),
            total_cost=round(r.total_cost, 2),
            total_profit=round(r.total_revenue - r.total_cost, 2),
        )
        for r in rows
    ]


def get_low_stock(db: Session) -> list[schemas.LowStockItem]:
    ingredients = (
        db.query(models.Ingredient)
        .filter(models.Ingredient.quantity_on_hand <= models.Ingredient.reorder_threshold)
        .all()
    )
    return [
        schemas.LowStockItem(
            ingredient_id=i.id,
            name=i.name,
            quantity_on_hand=i.quantity_on_hand,
            reorder_threshold=i.reorder_threshold,
            unit=i.unit,
        )
        for i in ingredients
    ]
